/**
 * 엘리베이터 설정
 * 
 * controllers/baro_elevator.js 파일 참조
 * 
 * mode : dev, op
 * 
 * @author Mike
 */

// 모드 -> 테스트 : dev, 운영 : op
const mode = 'op';

if (mode == 'dev') {

    module.exports = {
        server: {
            host: 'localhost',
            port: 7130
        },
        elevatorIndex: {
            '1': 0,
            '2': 1
        }
    }

} else if (mode == 'op') {

    module.exports = {
        server: {
            host: '116.3.XXX.XXX',
            port: 7130
        },
        elevatorIndex: {
            '3': 0
        }
    }

}
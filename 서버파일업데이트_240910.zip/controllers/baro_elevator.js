/**
 * 엘리베이터 콘트롤러
 * 
 * 클라이언트 테스트 파일 /public/elevator/elevator_client1.html
 *    http://localhost:8001/elevator/elevator_client1.html
 * 
 *  
 */

'use strict'

const util = require('../util/util');
const param = require('../util/param');
const logger = require('../util/logger');

const systemUtil = require('util');

const Database = require('../database/database_mysql');
const elevatorSql = require('../database/sql/baro_elevator_sql');
 

const elevatorConfig = require('../config/elevator_config');
const ElevatorControl = require('../elevator/elevator_control');
 

//===== 엘리베이터 정보 매핑 START =====//

// robotId --> sessionId
const robotToSessionMap = new Map();

// sessionId --> elevatorControl
const sessionToElevatorControlMap = new Map();

//===== 엘리베이터 정보 매핑 END =====//


/**
 * @Controller(path="/baro_elevator/v1")
 */
class BaroElevator {

  ///
  /// 초기화
  ///
  constructor() {
    this.database = new Database('database_mysql');
    

    //===== 콜백 함수를 Promise로 만들기 START =====//
    
    this.startSession = systemUtil.promisify(this.startElevatorSession);
    this.endSession = systemUtil.promisify(this.endElevatorSession);

    //===== 콜백 함수를 Promise로 만들기 END =====//
    

  }

 
  
  ///
  /// 엘리베이터 세션 요청
  ///

  /**
   * @RequestMapping(path="/session", method="get,post")
   */
  async elevatorSession(req, res) {
    logger.debug('BaroElevator:elevatorSession called for POST /elevator/v1/session');

    const params = param.parse(req)
       
    try {
   
      if (params.command == 'start') {    // 세션 시작

          // 엘리베이터 세션 시작
          try {
            const data = await this.startSession(req, res, params, params.organizationId, params.elevatorType, params.elevatorId, params.robotType, params.robotId);
            
            const output = {
              code: 200,
              message: `OK`,
              header: {
                requestCode: params.requestCode
              },
              data: data
            }

            util.sendResponse(res, output);
    
          } catch(err) {
            const message = `세션 시작 시 에러 -> ${err}, 엘리베이터 서버 연결 가능 여부를 관리자에게 문의해주세요. 엘리베이터 서버 정보 -> host : ${elevatorConfig.server.host}, port : ${elevatorConfig.server.port}`;
            logger.error(message);
                
            return util.sendError(res, 400, message);
          }
            
      } else if (params.command == 'end') {    // 세션 종료
          // 엘리베이터 세션 종료
          try {
            const data = await this.endSession(req, res, params);

            const output = {
              code: 200,
              message: `OK`,
              header: {
                requestCode: params.requestCode
              },
              data: data
            }

            util.sendResponse(res, output);
    
          } catch(err) {
            const message = `세션 종료 시 에러 -> ${err}`;
            logger.error(message);
                
            return util.sendError(res, 400, message);
          }

      } else {
          const message = `Unknown command : ${params.command}`;
          logger.error(message);

          return util.sendError(res, 400, message);
      }
      
      
    } catch(err) {
      util.sendError(res, 400, `Error in execute -> ${err}`);

    }
  }
 
    
  ///
  /// 엘리베이터 호출 요청
  ///

  /**
   * @RequestMapping(path="/call", method="get,post")
   */
  async elevatorCall(req, res) {
    logger.debug('BaroElevator:elevatorCall called for POST /elevator/v1/call');

    const params = param.parse(req)
       
    try {
   
    
      // 세션으로 맵에서 ElevatorControl 객체 가져오기
      const elevatorControl = sessionToElevatorControlMap.get(params.sessionId);

      if (params.command == 'from') {    // 탑승층 호출

        try {

          // 탑승층 호출 요청 
          const result = await elevatorControl.carCallStart(params.floor);
          logger.debug(`탑승층 호출 요청 결과 : ${result}`);

          // 응답
          const output = {
            code: 200,
            message: `OK`,
            header: {
              requestCode: params.requestCode
            },
            data: {
              command: params.command
            }
          }

          util.sendResponse(res, output);

        } catch(err) {
          const message = `에러 -> ${err}`;
          logger.error(message);
              
          return util.sendError(res, 400, message);
            
        }

      } else if (params.command == 'to') {    // 목적층 호출

        try {

          // 목적층 호출 요청 
          const result = await elevatorControl.carCallEnd(params.floor);
          logger.debug(`목적층 호출 요청 결과 : ${result}`);

          // 응답
          const output = {
            code: 200,
            message: `OK`,
            header: {
              requestCode: params.requestCode
            },
            data: {
              command: params.command
            }
          }

          util.sendResponse(res, output);

        } catch(err) {
          const message = `에러 -> ${err}`;
          logger.error(message);
              
          return util.sendError(res, 400, message);
        }

      } else {
        const message = `Unknown command : ${params.command}`;
        logger.error(message);
            
        return util.sendError(res, 400, message);
          
      }
        
      
    } catch(err) {
      util.sendError(res, 400, `Error in execute -> ${err}`);

    }
  }
 

  ///
  /// 엘리베이터 탑승여부 통보
  ///

  /**
   * @RequestMapping(path="/boarding", method="get,post")
   */
  async elevatorBoarding(req, res) {
    logger.debug('BaroElevator:elevatorBoarding called for POST /elevator/v1/boarding');

    const params = param.parse(req)
       
    try {
  
      // 세션으로 맵에서 ElevatorControl 객체 가져오기
      const elevatorControl = sessionToElevatorControlMap.get(params.sessionId);

      if (params.command == 'on') {    // 탑승완료 통보

        try {

          // 도어클로즈(탑승층) 통보 요청 
          const result = await elevatorControl.doorCloseStart();
          logger.debug(`도어클로즈(탑승층) 통보 요청 결과 : ${result}`);

          // 응답
          const output = {
            code: 200,
            message: `OK`,
            header: {
              requestCode: params.requestCode
            },
            data: {
              command: params.command
            }
          }

          util.sendResponse(res, output);
            
        } catch(err) {
          const message = `에러 -> ${err}`;
          logger.error(message);
              
          return util.sendError(res, 400, message);
        }

      } else if (params.command == 'off') {    // 하차완료 통보
          
        try {

          // 도어클로즈(목적층) 통보 요청 
          const result = await elevatorControl.doorCloseEnd();
          logger.debug(`도어클로즈(목적층) 통보 요청 결과 : ${result}`);

          // 응답
          const output = {
            code: 200,
            message: `OK`,
            header: {
              requestCode: params.requestCode
            },
            data: {
              command: params.command
            }
          }

          util.sendResponse(res, output);

        } catch(err) {
          const message = `에러 -> ${err}`;
          logger.error(message);
              
          return util.sendError(res, 400, message);
        }

      } else {
        const message = `Unknown command : ${params.command}`;
        logger.error(message);
            
        return util.sendError(res, 400, message);
          
      }
        
         
    } catch(err) {
      util.sendError(res, 400, `Error in execute -> ${err}`);

    }
  }
 
  
  ///
  /// 엘리베이터 상태조회
  ///

  /**
   * @RequestMapping(path="/status", method="get,post")
   */
  async elevatorStatus(req, res) {
    logger.debug('BaroElevator:elevatorStatus called for POST /elevator/v1/status');

    const params = param.parse(req)
       
    try {
   
      const elevatorControl = sessionToElevatorControlMap.get(params.sessionId);
      if (elevatorControl) {

        if (!elevatorControl.connected) {
          const message = `엘리베이터 서버에 연결 안됨.`
          return util.sendError(res, 400, message);
        }
 
        const output = {
          code: 200,
          message: `OK`,
          header: {
            requestCode: params.requestCode
          },
          data: {
            organizationId: elevatorControl.organizationId,
            elevatorType: elevatorControl.elevatorType,
            elevatorId: elevatorControl.elevatorId,
            robotType: elevatorControl.robotType,
            robotId: elevatorControl.robotId,
            operation: elevatorControl.operationStatus,
            direction: elevatorControl.direction,
            floor: elevatorControl.currentFloorId,
            door: elevatorControl.doorStatus,
            step: elevatorControl.getStep(),
            elevatorStatus1: elevatorControl.elevatorStatus1,
            elevatorStatus2: elevatorControl.elevatorStatus2,
            elevatorStatus3: elevatorControl.elevatorStatus3,
            elevatorStatus4: elevatorControl.elevatorStatus4
          }
        }

        util.sendResponse(res, output);

      } else {
        const message = `Invalid session : ${params.sessionId}`;
        logger.error(message);
            
        return util.sendError(res, 400, message);
      }
  
      
    } catch(err) {
      util.sendError(res, 400, `Error in execute -> ${err}`);

    }
  }
 

  ///
  /// 엘리베이터 세션 시작하기
  ///
  startElevatorSession(req, res, params, organizationId, elevatorType, elevatorId, robotType, robotId, callback) {
    logger.debug(`startElevatorSession 호출됨.`);
    logger.debug(`elevator server info from /config/elevator_config.js -> host : ${elevatorConfig.server.host}, port : ${elevatorConfig.server.port}`);


    // 엘리베이터 콘트롤 객체 만들기
    const elevatorControl = new ElevatorControl(elevatorConfig.server.host, elevatorConfig.server.port, organizationId, elevatorType, elevatorId, robotType, robotId, null, (err, session) => {
      if (err) {
        // 에러 발생
        callback(err, null);
        return;
      }
      
      logger.debug(`Main::Session created -> robotId : ${robotId}, elevatorId : ${elevatorId}, session : ${session}`);

      // 세션 시작
      this.onSessionStarted(session, elevatorControl);

      // 맵에 추가
      robotToSessionMap.set(robotId, session);
      sessionToElevatorControlMap.set(session, elevatorControl);

      const data = {
        command: params.command,
        sessionId: session 
      }

      callback(null, data);

    });
  
  }


  ///
  /// 세션 시작 시 자동 호출되는 함수
  ///
  async onSessionStarted(session, elevatorControl) {
      logger.debug(`Main::onSessionStarted 호출됨.`);
    
      try {
    
        // 1. 서비스 시작 요청
        const result = await elevatorControl.serviceStart();
        logger.debug(`서비스 시작 요청 : ${result}`);
    
      } catch(err) {
        logger.error(`에러 -> ${err}`);
      }
        
  }


  ///
  /// 엘리베이터 세션 종료하기
  ///
  endElevatorSession(req, res, params, callback) {

    const elevatorControl = sessionToElevatorControlMap.get(params.sessionId);
    if (elevatorControl) {

      const currentSession = elevatorControl.endSession();
      logger.debug(`세션이 종료되었습니다 -> robotId : ${elevatorControl.robotId}, elevatorId : ${elevatorControl.elevatorId}, session : ${params.sessionId}`);

      // 맵에서 삭제
      robotToSessionMap.delete(elevatorControl.robotId);
      sessionToElevatorControlMap.delete(params.sessionId);
      logger.debug(`맵에서 세션 정보를 삭제하였습니다.`);

      const data = {
        command: params.command
      }

      callback(null, data);

    } else {

      callback(`Invalid session : ${params.sessionId}`, null);

    }

  }

 


}


module.exports = BaroElevator;


// net 라이브러리 사용
const net = require('net');
const util = require('util');
const moment = require('moment');
 
const ElevatorDataEncoder = require('./elevator_data_encoder');
const ElevatorSession = require('./elevator_session');

const elevatorConfig = require('../config/elevator_config');


// 폴링을 유지할 시간 (분)
const pollingLimit = 1;



///
/// 엘리베이터 제어 클래스 정의
///
class ElevatorControl {

  constructor(host, port, organizationId, elevatorType, elevatorId, robotType, robotId, responseCallback, callback) {
    
    this.responseCallback = responseCallback;

    this.intervalId = null;

    // 이전 요청 시간
    this.pollingOffset = moment();


    // 호스트, 포트 변수
    this.host = host;
    this.port = port;

    // 연결 여부
    this.connected = false;

    // 로봇ID, 엘리베이터ID 변수
    this.organizationId = organizationId;
    this.elevatorType = elevatorType;
    this.elevatorId = elevatorId;
    this.robotType = robotType;
    this.robotId = robotId;
    
    // 탑승층, 목적층
    this.startFloorId = 0;
    this.endFloorId = 0;


    // 이전 로봇상태 보관 (폴링을 위해)
    this.robotStatus1 = 0x00;    
    this.robotStatus2 = 0x00; 


    // 현재 엘리베이터 상태
    this.operationStatus = '';   // 운영 상태
    this.currentFloorId = -1;   // 현재 층
    this.direction = '';        // 방향
    this.doorStatus = '';   // 도어 상태


    // 진행 단계별 완료 여부
    this.step2Done = false;
    this.step4Done = false;
    this.step6Done = false;
    this.step8Done = false;
    this.step10Done = false;
    this.step12Done = false;
    this.step14Done = false;
    this.step16Done = false;
     

    // 수신한 엘리베이터 상태 정보
    this.elevatorStatus1 = '';
    this.elevatorStatus2 = '';
    this.elevatorStatus3 = '';
    this.elevatorStatus4 = '';


    // 옵션 설정
    this.timeout = 5000;
    this.encoding = 'utf8';

    // 엘리베이터 데이터 인코더 객체
    this.elevatorData = new ElevatorDataEncoder();

    // 엘리베이터 세션 객체
    this.elevatorSession = new ElevatorSession();


    // 버퍼 초기화 (빈 버퍼 생성)
    this.buffer = Buffer.alloc(0);

    // 소켓 연결 시도
    this.client = net.createConnection({ port: port, host: host }, (err) => {
      console.dir(err);
      console.log(`소켓 서버 연결됨 : ${this.client.remoteAddress}:${this.client.remotePort}`);
      
      // 연결 여부
      this.connected = true;

      // 클라이언트 초기화
      this.initClient();
  
      // 엘리베이터 세션 시작
      const session = this.elevatorSession.createSession(this.robotId);
    
      // 콜백 호출
      callback(null, session);


      /*
      // 8초마다 폴링 시작
      this.intervalId = setInterval(() => {

        // 이전 요청보다 10분 이상 지났다면 종료 
        const now = moment();
        if (now.diff(this.pollingOffset, 'minutes') >= pollingLimit) {
          
          // 연결 종료
          this.endSession();
          console.log(`요청이 없어 폴링 및 세션 중지됨 -> pollingOffset : ${this.pollingOffset}, pollingLimit : ${pollingLimit} minutes`);

          return;
        }

        this.requestPoll();

      }, 8000);
      */


    });

    // Reject on error
    this.client.on('error', (err) => {
      console.log(`소켓 연결 시 에러 : ${err}`);

      // 콜백 호출
      callback(`소켓 연결 시 에러 : ${err}`, null);
    });


    // 프로미스로 만들기
    this.serviceStart = util.promisify(this.requestServiceStart);
    this.serviceEnd = util.promisify(this.requestServiceEnd);

    this.carCallStart = util.promisify(this.requestCarCallStart);
    this.carCallEnd = util.promisify(this.requestCarCallEnd);

    this.doorOpenStart = util.promisify(this.requestDoorOpenStart);
    this.doorOpenEnd = util.promisify(this.requestDoorOpenEnd);
    
    this.doorCloseStart = util.promisify(this.requestDoorCloseStart);
    this.doorCloseEnd = util.promisify(this.requestDoorCloseEnd);

    this.rideComplete = util.promisify(this.requestRideComplete);
    this.offComplete = util.promisify(this.requestOffComplete);



  }

  
  ///
  /// 클라이언트 초기화
  ///
  initClient() {
    console.log(`ElevatorControl::initClient 호출됨.`);
      
    // 타임아웃 설정
    this.client.timeout = this.timeout;
 
    // 데이터 수신 이벤트 처리
    // 데이터 수신 후 클라이언트 5초 후 연결 끊기
    this.client.on('data', data => {
      console.log(`\n[Elevator->Platform] Received data from server: ${data.toString('hex').toUpperCase()}`);

      // 수신한 데이터를 버퍼에 넣기
      this.buffer = Buffer.concat([this.buffer, data]);

      // STX, Type, Length를 합쳐 최소한 6 bytes 이상일때만 처리함
      while (this.buffer.length >= 6) {
          
        // 수신한 데이터 처리
        // 데이터 처리 후 남은 데이터가 전부 수신되지 않은 상태라면 while문 종료
        const ready = this.processData();
        if (!ready) {
          break;
        }

      }


      // setTimeout(() => {
      //   client.end();
      // }, 5000)
      
    });

    // 데이터가 남아있다는 이벤트 처리
    this.client.on('drain', () => {
      console.log(`Drain called.`);

    });

    // 클라이언트 연결 끊김 이벤트 처리
    this.client.on('end', () => {
      console.log(`Disconnected from socket server`);

      // 연결 종료
      this.endSession();
    });

    //
    // 클라이언트 소켓 에러 이벤트 처리
    // (1) ECONNRESET : 서버에서 강제로 연결을 끊은 경우
    // 
    this.client.on('error', (e) => {
      if (e.code === 'ECONNRESET') {   // 서버에서 강제로 연결 끊음
        console.error(`서버에서 강제로 연결을 끊었습니다 -> ${this.client.remoteAddress}:${this.client.remotePort}`);
      
        // 연결 종료
        this.endSession();
        
      } else if (e.code === 'ECONNREFUSED') {   // 서버 연결 안됨
        console.error(`서버로 연결이 안됩니다 -> ${host}:${port}`);
      }
    }); 


  }


  // 현재 진행단계 조회
  getStep() {
    
    // 이전 요청 시간 갱신
    this.pollingOffset = moment();
    
    return this.elevatorSession.getStep(this.robotId);
  }

  ///
  /// 수신한 데이터 처리
  ///
  processData() {
    console.log(`ElevatorControl::processData 호출됨.`);

    const currentStep = this.elevatorSession.getStep(this.robotId);
    console.log(`currentStep : ${currentStep}`);


    // STX : 1 byte
    const stx = this.buffer.readUInt8(0);

    // Type : 1 byte
    const type = this.buffer.readUInt8(1);

    // Length : 4 bytes
    const length = this.buffer.readUInt32BE(2);

    console.log(`stx=${stx}, type=${type}, length=${length}`);

    // value가 전부 수신되지 않았다면 처리하지 않고 넘어감
    if (this.buffer.length < (6 + length + 3)) {
        return false;
    }

    // value 길이만큼 잘라내어 처리함
    const value = this.buffer.slice(6, 6 + length);
    const output = this.processValue(stx, type, length, value);
    //console.log(`elevator data output : ${JSON.stringify(output)}`);


    // 처리한 데이터는 buffer에서 제거함
    this.buffer = this.buffer.slice(6 + length + 3);

    //console.log(`value=${value.toString()}`);
 

    return true;
  }

  ///
  /// 헤더와 푸터를 제외한 값 처리
  ///
  processValue(stx, type, length, value) {
    console.log(`ElevatorControl::processValue 호출됨.`);

    let outputType;   // 결과 유형
    let output;

    let currentStep = this.elevatorSession.getStep(this.robotId);
    console.log(`currentStep : ${currentStep}`);
    
    if (type == 0x45) {     // Service 응답
      console.log(`service response`);

      outputType = 'service';
      output = this.elevatorData.decodeServiceValue(value);

      if (currentStep == 1) {
        console.log(`output.command : ${output.command}`);

        if (output.command == 'serviceStart') { // 서비스 시작 응답
          console.log(`서비스 시작 응답 받음 -> robotId : ${this.robotId}, elevatorId : ${this.elevatorId}`);
          this.elevatorSession.setStep(this.robotId, 2);   // 2단계

        }
        
      }

    } else if (type == 0x65) {     // ElevatorInfo 응답
      
      outputType = 'elevator';
      const outputArray = this.elevatorData.decodeElevatorInfoValue(value);
      

      // MIKE START 240909
      // 엘리베이터 아이디로 인덱스 확인
      const outputIndex = elevatorConfig.elevatorIndex[this.elevatorId];
      console.log(`elevator index : ${outputIndex}`);

      // const outputIndex = Number(this.elevatorId)-1;
      // console.log(`outputIndex : ${outputIndex}`);

      output = outputArray[outputIndex];

        
      // if (currentStep == 12) {   // 현재 단계가 12단계이면

      //   if (output.elevatorStatus == 'up' || output.elevatorStatus == 'down') {
      //     console.log(`엘리베이터 정보 UP 또는 DOWN 응답 받음 -> robotId : ${this.robotId}, elevatorId : ${this.elevatorId}`);
      //     this.elevatorSession.setStep(this.robotId, 13);   // 13단계
      //   }

      // } else if (currentStep == 13) {   // 현재 단계가 13단계이면

      //   if (output.elevatorStatus == 'stop') {
      //     console.log(`엘리베이터 정보 STOP 응답 받음 -> robotId : ${this.robotId}, elevatorId : ${this.elevatorId}`);
      //     this.elevatorSession.setStep(this.robotId, 14);   // 14단계
      //   }

      // } else if (currentStep == 15) {   // 현재 단계가 15단계이면

      //   if (output.elevatorStatus == 'frontopen' || output.elevatorStatus == 'backopen') {
      //     console.log(`엘리베이터 정보 frontopen 또는 backopen 응답 받음 -> robotId : ${this.robotId}, elevatorId : ${this.elevatorId}`);
      //     this.elevatorSession.setStep(this.robotId, 16);   // 16단계
      //   }

      if (currentStep == 19) {   // 현재 단계가 19단계이면

        console.log(`엘리베이터 정보 19단계 응답 받음 -> robotId : ${this.robotId}, elevatorId : ${this.elevatorId}`);
        this.elevatorSession.setStep(this.robotId, 20);   // 20단계

      }

    } else if (type == 0x61) {     // RobotInfo 응답

      outputType = 'robot';
      output = this.elevatorData.decodeRobotInfoValue(value);
      
      console.log(`controlRequest binary : ${output.controlRequest.toString(2)}`);
 
      /*
      if (output.controlRequest) {
        if (output.controlRequest == (1 << 4)) {    // 도어 오픈 요청에 대한 응답

          if (currentStep == 5) {   // 현재 단계가 5단계이면 6단계로 변경
            console.log(`로봇 정보 5단계 응답 받음 -> robotId : ${this.robotId}, elevatorId : ${this.elevatorId}`);
            this.elevatorSession.setStep(this.robotId, 6);   // 6단계
          }

        } else if (output.controlRequest == (1 << 3)) {    // 도어 클로즈 요청에 대한 응답

          if (currentStep == 9) {   // 현재 단계가 8단계이면 9단계로 변경
            console.log(`로봇 정보 9단계 응답 받음 -> robotId : ${this.robotId}, elevatorId : ${this.elevatorId}`);
            this.elevatorSession.setStep(this.robotId, 10);   // 10단계
          }

        } else if (output.controlRequest == (1 << 5)) {    // 카 콜 요청에 대한 응답

          if (currentStep == 3) {   // 현재 단계가 3단계이면 4단계로 변경
            console.log(`로봇 정보 3단계 응답 받음 -> robotId : ${this.robotId}, elevatorId : ${this.elevatorId}`);
            this.elevatorSession.setStep(this.robotId, 4);   // 5단계
          } else if (currentStep == 7) {   // 현재 단계가 7단계이면 8단계로 변경
            console.log(`로봇 정보 7단계 응답 받음 -> robotId : ${this.robotId}, elevatorId : ${this.elevatorId}`);
            this.elevatorSession.setStep(this.robotId, 8);   // 8단계
          }

        }
        
      }

      */
       
      if (currentStep == 3) {   // 현재 단계가 3단계이면

        console.log(`로봇 정보 3단계 응답 받음 -> robotId : ${this.robotId}, elevatorId : ${this.elevatorId}`);
        this.elevatorSession.setStep(this.robotId, 4);   // 4단계
      
      } else if (currentStep == 5) {   // 현재 단계가 5단계이면

        console.log(`로봇 정보 5단계 응답 받음 -> robotId : ${this.robotId}, elevatorId : ${this.elevatorId}`);
        this.elevatorSession.setStep(this.robotId, 6);   // 6단계
      
      } else if (currentStep == 7) {   // 현재 단계가 7단계이면

        console.log(`로봇 정보 7단계 응답 받음 -> robotId : ${this.robotId}, elevatorId : ${this.elevatorId}`);
        this.elevatorSession.setStep(this.robotId, 8);   // 8단계
      
      } else if (currentStep == 9) {   // 현재 단계가 9단계이면

        console.log(`로봇 정보 9단계 응답 받음 -> robotId : ${this.robotId}, elevatorId : ${this.elevatorId}`);
        this.elevatorSession.setStep(this.robotId, 10);   // 10단계
      
      } else if (currentStep == 11) {   // 현재 단계가 11단계이면

        console.log(`로봇 정보 11단계 응답 받음 -> robotId : ${this.robotId}, elevatorId : ${this.elevatorId}`);
        this.elevatorSession.setStep(this.robotId, 12);   // 12단계
      
      } else if (currentStep == 13) {   // 현재 단계가 13단계이면

        console.log(`로봇 정보 13단계 응답 받음 -> robotId : ${this.robotId}, elevatorId : ${this.elevatorId}`);
        this.elevatorSession.setStep(this.robotId, 14);   // 14단계
      
      } else if (currentStep == 15) {   // 현재 단계가 15단계이면

        console.log(`로봇 정보 15단계 응답 받음 -> robotId : ${this.robotId}, elevatorId : ${this.elevatorId}`);
        this.elevatorSession.setStep(this.robotId, 16);   // 16단계
      
      } else if (currentStep == 17) {   // 현재 단계가 17단계이면

          console.log(`로봇 정보 17단계 응답 받음 -> robotId : ${this.robotId}, elevatorId : ${this.elevatorId}`);
          this.elevatorSession.setStep(this.robotId, 18);   // 18단계
        
      } else if (currentStep == 19) {   // 현재 단계가 19단계이면

        console.log(`로봇 정보 19단계 응답 받음 -> robotId : ${this.robotId}, elevatorId : ${this.elevatorId}`);
        this.elevatorSession.setStep(this.robotId, 20);   // 20단계
      
      }

    }


    currentStep = this.elevatorSession.getStep(this.robotId);
    console.log(`currentStep : ${currentStep}`);


    // 응답이 엘리베이터 정보라면, 현재 상태 설정
    if (outputType == 'elevator') {

      // 운행 상태 판단
      this.operationStatus = 'on';

      this.elevatorStatus1 = output.elevatorStatus1;
      this.elevatorStatus2 = output.elevatorStatus2;
      this.elevatorStatus3 = output.elevatorStatus3;
      this.elevatorStatus4 = output.elevatorStatus4;


      // Status1의 불가 데이터 확인
      if (output.elevatorStatus1.indexOf('FD') > -1 || output.elevatorStatus1.indexOf('OVR') > -1 || 
          output.elevatorStatus1.indexOf('HCB') > -1 || output.elevatorStatus1.indexOf('Parking') > -1 ||
          output.elevatorStatus1.indexOf('IND') > -1 || output.elevatorStatus1.indexOf('INS') > -1) {
            this.operationStatus = 'off';
      }

      // Status1의 불가 데이터 중 AUT가 없으면 운행 불가, AUT이면서 Data4의 불가 데이터가 있으면 운행 불가
      if (output.elevatorStatus1.indexOf('AUT') < 0) {
        this.operationStatus = 'off';
      }

      // Status2의 불가 데이터 확인
      if (output.elevatorStatus2.indexOf('SW3') > -1 || output.elevatorStatus2.indexOf('RSQ') > -1 || 
          output.elevatorStatus2.indexOf('ARD') > -1 || output.elevatorStatus2.indexOf('VIP') > -1 ||
          output.elevatorStatus2.indexOf('CANNING') > -1 || output.elevatorStatus2.indexOf('EC') > -1) {
            this.operationStatus = 'off';
      }

      // Status3의 불가 데이터 확인
      if (output.elevatorStatus3.indexOf('TCF') > -1 || output.elevatorStatus3.indexOf('TC') > -1 || 
          output.elevatorStatus3.indexOf('PC') > -1 || output.elevatorStatus3.indexOf('PITW') > -1 ||
          output.elevatorStatus3.indexOf('CAPT') > -1) {
            this.operationStatus = 'off';
      }
 
      // Status3의 불가 데이터 중 EPNP가 없으면 운행 불가
      if (output.elevatorStatus3.indexOf('EPNP') < 0) {
        this.operationStatus = 'off';
      }
      
      // Status4의 불가 데이터 확인
      if (output.elevatorStatus4.indexOf('HML3') > -1 || output.elevatorStatus4.indexOf('HML2') > -1 || 
          output.elevatorStatus4.indexOf('Parking2') > -1) {
            this.operationStatus = 'off';
      }
 

      // 현재 층
      this.currentFloorId = output.floorId;   

      // 진행 방향
      if (output.elevatorStatus4.length > 0) {
        this.direction = output.elevatorStatus4;      
      } else {
        this.direction = '';
      }

      // 도어 상태
      if (output.elevatorStatus3.indexOf('DOL') > -1) {
        this.doorStatus = 'open';   
      } else {
        this.doorStatus = 'close';
      }

    }


    // 응답 콜백 함수 호출 (여기에서는 null이므로 사용 안함)
    // if (this.responseCallback) {
    //   this.responseCallback(currentStep, outputType, 
    //                         this.operationStatus, this.currentFloorId, this.direction, this.doorStatus, 
    //                         output);
    // }


    // 응답 처리
    
    console.log(`\nElevatorControl::response -> currentStep : ${currentStep}, outputType : ${outputType}`);
    console.log(`operationStatus : ${this.operationStatus}, currentFloorId : ${this.currentFloorId}, direction: ${this.direction}, doorStatus : ${this.doorStatus}`);
    console.log(`output : ${JSON.stringify(output)}`);

    // 진행단계별 호출
  
    if (outputType == 'elevator') {     // 엘리베이터 정보 응답인 경우
      
      if (currentStep == 4) {  // 진행단계 4이고 진행방향이 Stop이고 floorId가 탑승층과 같다면 도어오픈(탑승층) 호출
  
        //if (output.elevatorStatus4 == 'Stop' && output.floorId == this.startFloorId) {
        if (output.floorId == this.startFloorId) {
  
          if (!this.step4Done) {
            
            try {
              const result = this.doorOpenStart();
              console.log(`도어오픈(탑승층) 호출 결과 : ${result}`);


              // 10초마다 폴링 시작
              if (this.intervalId) {
                clearInterval(this.intervalId);
              }

              this.intervalId = setInterval(() => {

                // 이전 요청보다 10분 이상 지났다면 종료 
                const now = moment();
                if (now.diff(this.pollingOffset, 'minutes') >= pollingLimit) {
                  
                  this.endSession();
                  console.log(`요청이 없어 도어오픈(탑승층) 호출 및 세션 중지됨 -> pollingOffset : ${this.pollingOffset}, pollingLimit : ${pollingLimit} minutes`);

                  return;
                }

                this.requestDoorOpenStartOnly();

              }, 10000);


              this.step4Done = true;
            } catch(err) {
              console.err(`Error : ${err}`);
            }

          }
  
        }
  
      } else if (currentStep == 6) {  // 진행단계 6이고 도어가 오픈되어 있고 floorId가 탑승층과 같다면 탑승 시작
  
        if (output.elevatorStatus3.indexOf('DOL') > -1 && output.floorId == this.startFloorId) {
          console.log(`로봇이 엘리베이터로 탑승중입니다.`);
        }
  
  
      } else if (currentStep == 10) {  // 진행단계 10이면 탑승완료 통보
   
        //if (output.elevatorStatus4 == 'Stop' && output.floorId == this.endFloorId) {
        if (output.floorId == this.endFloorId) {

          if (!this.step10Done) {
            
            try {

              // 문열림 폴링 중지
              if (this.intervalId) {
                clearInterval(this.intervalId);
                console.log(`문열림 폴링 중지됨`);
              }


              const result = this.rideComplete();
              console.log(`탑승완료 통보 결과 : ${result}`);


              this.step10Done = true;
            } catch(err) {
              console.err(`Error : ${err}`);
            }
  
          }
        }
  
      } else if (currentStep == 12) {  // 진행단계 12이고 진행방향이 Stop이고 floorId가 목적층과 같다면 도어오픈(목적층) 문열림 호출
   
        //if (output.elevatorStatus4 == 'Stop' && output.floorId == this.endFloorId) {
        if (output.floorId == this.endFloorId) {

          if (!this.step12Done) {
            
            try {
              const result = this.doorOpenEnd();
              console.log(`도어오픈(목적층) 호출 결과 : ${result}`);


              // 10초마다 폴링 시작
              if (this.intervalId) {
                clearInterval(this.intervalId);
              }

              this.intervalId = setInterval(() => {

                // 이전 요청보다 10분 이상 지났다면 종료 
                const now = moment();
                if (now.diff(this.pollingOffset, 'minutes') >= pollingLimit) {
                  
                  this.endSession();
                  console.log(`요청이 없어 도어오픈(탑승층) 호출 및 세션 중지됨 -> pollingOffset : ${this.pollingOffset}, pollingLimit : ${pollingLimit} minutes`);

                  return;
                }

                this.requestDoorOpenEndOnly();

              }, 10000);


              this.step12Done = true;
            } catch(err) {
              console.err(`Error : ${err}`);
            }
  
          }
        }
  
      } else if (currentStep == 14) {  // 진행단계 14이고 도어가 오픈되어 있고 floorId가 목적층과 같다면 하차 시작
  
        if (output.elevatorStatus3.indexOf('DOL') > -1 && output.floorId == this.endFloorId) {
          console.log(`로봇이 엘리베이터로부터 하차중입니다.`);
        }
  
      }
  
    }
  
    
    if (outputType == 'robot') {     // 로봇 정보 응답인 경우
   
      if (currentStep == 16) {  // 진행단계 16이면 하차완료 호출
        
        if (!this.step16Done) {

          try {
            
            // 문열림 폴링 중지
            if (this.intervalId) {
              clearInterval(this.intervalId);
              console.log(`문열림 폴링 중지됨`);
            }


            const result = this.offComplete();
            console.log(`하차완료 호출 결과 : ${result}`);


            this.step16Done = true;
          } catch(err) {
            console.err(`Error : ${err}`);
          }
 
        }
     
      } else if (currentStep == 18) {  // 진행단계 18이면 하차완료된 것이므로 단계를 기본값으로 초기화
   
        this.step2Done = false;
        this.step4Done = false;
        this.step6Done = false;
        this.step8Done = false;
        this.step10Done = false;
        this.step12Done = false;
        this.step14Done = false;
        this.step16Done = false;
        

      }
  
    }
   
     

    return output;
  }
 

  ///
  /// 서비스 시작 요청
  ///
  requestServiceStart(callback) {
    console.log(`\nElevatorControl::requestServiceStart 호출됨.`);
     
    // 서비스 데이터를 인코딩하여 보내기 (서비스 시작)
    // 응답 : 전체 엘리베이터 상태 응답
    const cmd = 0x53;

    const encodedBuffer = this.elevatorData.encodeServiceRequest(cmd);
    console.log(`전송할 데이터 : ${encodedBuffer.toString('hex').toUpperCase()}`);
    
    this.client.write(encodedBuffer, this.encoding, () => {
      console.log(`서비스 시작 요청 완료`);

      // 진행단계 변경 : 1단계
      this.elevatorSession.setStep(this.robotId, 1);

      callback(null, true);
    });

    // 이전 요청 시간 갱신
    this.pollingOffset = moment();
  }

  ///
  /// 서비스 종료 요청
  ///
  requestServiceEnd(callback) {
    console.log(`\nElevatorControl::requestServiceEnd 호출됨.`);
    
    // 서비스 데이터를 인코딩하여 보내기 (서비스 종료)
    // 응답 : 
    const cmd = 0x45;

    const encodedBuffer = this.elevatorData.encodeServiceRequest(cmd);
    console.log(`전송할 데이터 : ${encodedBuffer.toString('hex').toUpperCase()}`);
    
    this.client.write(encodedBuffer, this.encoding, () => {
      console.log(`서비스 종료 데이터 전송 완료`);
      
      // 진행단계 변경 : 19단계
      this.elevatorSession.setStep(this.robotId, 19);

      callback(null, true);
    });

    // 이전 요청 시간 갱신
    this.pollingOffset = moment();
  }


  ///
  /// 폴링
  ///
  requestPoll(callback) {
    console.log(`requestPoll 호출됨.`);
    
    // 폴링 요청
    const floorId = 0x00;
    const controlRequest = 0x00;
     
    const encodedBuffer = this.elevatorData.encodeRobotInfoRequest(
      this.robotId, 
      this.elevatorId, 
      floorId, 
      controlRequest, 
      this.robotStatus1, 
      this.robotStatus2
    );
    console.log(`전송할 데이터 : ${encodedBuffer.toString('hex').toUpperCase()}`);
    
    this.client.write(encodedBuffer, this.encoding, callback);
 
  }

  ///
  /// 탑승층 호출
  ///
  requestCarCallStart(floorId, callback) {
    
    // 탑승층 저장
    this.startFloorId = floorId;

    // 카 콜 요청 (탑승층)
    this.robotStatus1 = 1 << 6;    // 탑승대기
    this.requestCarCall(floorId, this.robotStatus1, () => {
      console.log(`카 콜 데이터 전송 완료`);
    
      // 진행단계 등록 : 3단계
      this.elevatorSession.setStep(this.robotId, 3);

      callback(null, true);
    });
     
  }

  ///
  /// 목적층 호출
  ///
  requestCarCallEnd(floorId, callback) {
    
    // 문열림 폴링 중지
    if (this.intervalId) {
      clearInterval(this.intervalId);
      console.log(`문열림 폴링 중지됨`);
    }


    // 목적층 저장
    this.endFloorId = floorId;

    // 카 콜 요청 (목적층)
    //this.robotStatus1 = 1 << 4;    // 탑승완료
    this.robotStatus1 = 1 << 5;    // 탑승중
    this.requestCarCall(floorId, this.robotStatus1, () => {
      console.log(`카 콜 데이터 전송 완료`);
    
      // 진행단계 등록 : 7단계
      this.elevatorSession.setStep(this.robotId, 7);
      
      callback(null, true);
    });
    
  }

  ///
  /// 카 콜 요청
  ///
  /// robotId 로봇 ID
  /// elevatorId 엘리베이터 ID
  /// floorId 탑승층, 목적층
  ///
  requestCarCall(floorId, robotStatus1, callback) {
    console.log(`\nElevatorControl::requestCarCall 호출됨.`);
    
    // 2. 로봇정보 데이터를 인코딩하여 보내기 (카 콜 층)
    // 2-1. ACK 응답
    this.robotStatus2 = 1 << 4;    // 통신상태
    const controlRequest = 1 << 5;  //  00010000  카 콜 버튼 등록

    const encodedBuffer = this.elevatorData.encodeRobotInfoRequest(
      this.robotId, 
      this.elevatorId, 
      floorId, 
      controlRequest, 
      robotStatus1, 
      this.robotStatus2
    );
    console.log(`전송할 데이터 : ${encodedBuffer.toString('hex').toUpperCase()}`);
    
    this.client.write(encodedBuffer, this.encoding, callback);
 
    this.robotStatus1 = robotStatus1;
    
    // 이전 요청 시간 갱신
    this.pollingOffset = moment();
  }

  
  ///
  /// 탑승층에서의 도어 오픈 호출
  ///
  requestDoorOpenStart(callback) {
    
    // 도어오픈 요청 (탑승층)
    this.robotStatus1 = 1 << 5;    // 탑승중
    this.requestDoorOpen(this.startFloorId, this.robotStatus1, () => {
      console.log(`도어오픈(탑승층) 데이터 전송 완료`);
    
      // 진행단계 등록 : 6단계
      this.elevatorSession.setStep(this.robotId, 5);
      
      callback(null, true);
    });
 
  }

  
  ///
  /// 탑승층에서의 도어 오픈 폴링 호출
  ///
  requestDoorOpenStartOnly() {
    
    // 도어오픈 요청 (탑승층)
    this.robotStatus1 = 1 << 5;    // 탑승중
    this.requestDoorOpen(this.startFloorId, this.robotStatus1, () => {
      console.log(`도어오픈(탑승층) 폴링 데이터 전송 완료`);
    });
 
  }

 
  ///
  /// 목적층에서의 도어 오픈 호출
  ///
  requestDoorOpenEnd(callback) {
    
    // 도어오픈 요청 (목적층)
    this.robotStatus1 = 1 << 3;    // 하차중
    this.requestDoorOpen(this.endFloorId, this.robotStatus1, () => {
      console.log(`도어오픈(목적층) 데이터 전송 완료`);
    
      // 진행단계 등록 : 13단계
      this.elevatorSession.setStep(this.robotId, 13);
      
      callback(null, true);
    });
  
  }

  
  ///
  /// 목적층에서의 도어 오픈 폴링 호출
  ///
  requestDoorOpenEndOnly() {
    
    // 도어오픈 요청 (목적층)
    this.robotStatus1 = 1 << 3;    // 하차중
    this.requestDoorOpen(this.endFloorId, this.robotStatus1, () => {
      console.log(`도어오픈(목적층) 폴링 데이터 전송 완료`);
    });
  
  }


  ///
  /// 도어 오픈 요청
  ///
  requestDoorOpen(floorId, robotStatus1, callback) {
    console.log(`\nElevatorControl::requestDoorOpen 호출됨.`);
  
    // PDO(Push Door Open) 요청 전송
    this.robotStatus2 = 1 << 4;    // 통신상태
    const controlRequest = 1 << 4;

    const encodedBuffer = this.elevatorData.encodeRobotInfoRequest(
      this.robotId, 
      this.elevatorId, 
      floorId, 
      controlRequest,
      robotStatus1, 
      this.robotStatus2
    );
    console.log(`전송할 데이터 : ${encodedBuffer.toString('hex').toUpperCase()}`);
    
    this.client.write(encodedBuffer, this.encoding, callback);

    this.robotStatus1 = robotStatus1;
    
    // 이전 요청 시간 갱신
    this.pollingOffset = moment();
  }
  
  ///
  /// 탑승층에서의 도어클로즈 호출
  ///
  requestDoorCloseStart(callback) {
    
    // 도어클로즈 요청 (탑승층)
    this.robotStatus1 = 1 << 4;    // 탑승완료
    this.requestDoorClose(this.startFloorId, this.robotStatus1, () => {
      console.log(`도어클로즈(탑승층) 데이터 전송 완료`);
    
      // 진행단계 등록 : 9단계
      this.elevatorSession.setStep(this.robotId, 9);
      
      callback(null, true);
    });
  
  }
 
  ///
  /// 목적층에서의 도어클로즈 호출
  ///
  requestDoorCloseEnd(callback) {
    
    // 도어클로즈 요청 (목적층)
    this.robotStatus1 = 1 << 2;    // 하차완료
    this.requestDoorClose(this.endFloorId, this.robotStatus1, () => {
      console.log(`도어클로즈(목적층) 데이터 전송 완료`);
    
      // 진행단계 등록 : 15단계
      this.elevatorSession.setStep(this.robotId, 15);
      
      callback(null, true);
    });
  
  }

  ///
  /// 도어 클로즈 요청
  ///
  requestDoorClose(floorId, robotStatus1, callback) {
    console.log(`\nElevatorControl::requestDoorClose 호출됨.`);
  
    // PDO(Push Door Close) 요청 전송
    this.robotStatus2 = 1 << 4;    // 통신상태
    const controlRequest = 1 << 3;

    const encodedBuffer = this.elevatorData.encodeRobotInfoRequest(
      this.robotId, 
      this.elevatorId, 
      floorId, 
      controlRequest,
      robotStatus1, 
      this.robotStatus2
    );
    console.log(`전송할 데이터 : ${encodedBuffer.toString('hex').toUpperCase()}`);
    
    this.client.write(encodedBuffer, this.encoding, callback);

    this.robotStatus1 = robotStatus1;
    
    // 이전 요청 시간 갱신
    this.pollingOffset = moment();
  }

  ///
  /// 탑승완료 요청
  ///
  requestRideComplete(callback) {
    console.log(`\nElevatorControl::requestRideComplete 호출됨.`);
  
    // 탑승완료 요청 전송
    const controlRequest = 0x00;
    this.robotStatus1 = 1 << 4;  //  탑승완료

    const encodedBuffer = this.elevatorData.encodeRobotInfoRequest(
      this.robotId, 
      this.elevatorId, 
      this.startFloorId, 
      controlRequest,
      this.robotStatus1
    );
    console.log(`전송할 데이터 : ${encodedBuffer.toString('hex').toUpperCase()}`);
    
    this.client.write(encodedBuffer, this.encoding, () => {
      //console.log(`탑승완료 데이터 전송 완료.`);
      
      this.elevatorSession.setStep(this.robotId, 11);   // 11단계

      callback(null, true);
    });
 
    // 이전 요청 시간 갱신
    this.pollingOffset = moment();
  }

  ///
  /// 하차완료 요청
  ///
  requestOffComplete(callback) {
    console.log(`\nElevatorControl::requestOffComplete 호출됨.`);
  
    // 하차완료 요청 전송
    const controlRequest = 0x00;
    this.robotStatus1 = 1 << 2;  //  하차완료

    const encodedBuffer = this.elevatorData.encodeRobotInfoRequest(
      this.robotId, 
      this.elevatorId, 
      this.endFloorId, 
      controlRequest,
      this.robotStatus1
    );
    console.log(`전송할 데이터 : ${encodedBuffer.toString('hex').toUpperCase()}`);
    
    this.client.write(encodedBuffer, this.encoding, () => {
      //console.log(`하차완료 데이터 전송 완료.`);

      this.elevatorSession.setStep(this.robotId, 17);   // 17단계

      callback(null, true);
    });
 
    // 이전 요청 시간 갱신
    this.pollingOffset = moment();
  }

  ///
  /// 세션 종료
  ///
  async endSession() {
    console.log(`endSession 호출됨.`);

    try {

      // 1. 하차완료 통보 요청
      let result = await this.offComplete();
      console.log(`하차완료 통보 요청 : ${result}`);

      // 1. 서비스 중지 요청
      result = await this.serviceEnd();
      console.log(`서비스 중지 요청 : ${result}`);
  
    } catch(err) {
      console.error(`에러 -> ${err}`);
    }
    
    // 폴링 중지
    if (this.intervalId) {
      clearInterval(this.intervalId);
      console.log(`폴링 중지됨`);
    }

    // 세션 정보 삭제
    const currentSession = this.elevatorSession.removeSession(this.robotId);

    // 3초 후에 소켓 연결 종료
    setTimeout(() => {

      //this.client.destroy(() => {
      this.client.end(() => {
        console.log(`소켓 연결 종료됨.`);

        // 연결 여부
        this.connected = false;

      });
      console.log(`소켓 연결 종료 요청함 -> 세션ID : ${currentSession}`);
  
    }, 3000)
   
    // 상태 초기화
    this.operationStatus = '';   // 운영 상태
    this.currentFloorId = -1;   // 현재 층
    this.direction = '';        // 방향
    this.doorStatus = '';   // 도어 상태

    return currentSession;
  }



}


module.exports = ElevatorControl;




// net 라이브러리 사용
const net = require('net');
  
//const { crc16 } = require('easy-crc');
 

var toBinaryString = require( '@stdlib/number-uint8-base-to-binary-string' );


const wCRCTable = [
  0X0000, 0XC0C1, 0XC181, 0X0140, 0XC301, 0X03C0, 0X0280, 0XC241,
  0XC601, 0X06C0, 0X0780, 0XC741, 0X0500, 0XC5C1, 0XC481, 0X0440,
  0XCC01, 0X0CC0, 0X0D80, 0XCD41, 0X0F00, 0XCFC1, 0XCE81, 0X0E40,
  0X0A00, 0XCAC1, 0XCB81, 0X0B40, 0XC901, 0X09C0, 0X0880, 0XC841,
  0XD801, 0X18C0, 0X1980, 0XD941, 0X1B00, 0XDBC1, 0XDA81, 0X1A40,
  0X1E00, 0XDEC1, 0XDF81, 0X1F40, 0XDD01, 0X1DC0, 0X1C80, 0XDC41,
  0X1400, 0XD4C1, 0XD581, 0X1540, 0XD701, 0X17C0, 0X1680, 0XD641,
  0XD201, 0X12C0, 0X1380, 0XD341, 0X1100, 0XD1C1, 0XD081, 0X1040,
  0XF001, 0X30C0, 0X3180, 0XF141, 0X3300, 0XF3C1, 0XF281, 0X3240,
  0X3600, 0XF6C1, 0XF781, 0X3740, 0XF501, 0X35C0, 0X3480, 0XF441,
  0X3C00, 0XFCC1, 0XFD81, 0X3D40, 0XFF01, 0X3FC0, 0X3E80, 0XFE41,
  0XFA01, 0X3AC0, 0X3B80, 0XFB41, 0X3900, 0XF9C1, 0XF881, 0X3840,
  0X2800, 0XE8C1, 0XE981, 0X2940, 0XEB01, 0X2BC0, 0X2A80, 0XEA41,
  0XEE01, 0X2EC0, 0X2F80, 0XEF41, 0X2D00, 0XEDC1, 0XEC81, 0X2C40,
  0XE401, 0X24C0, 0X2580, 0XE541, 0X2700, 0XE7C1, 0XE681, 0X2640,
  0X2200, 0XE2C1, 0XE381, 0X2340, 0XE101, 0X21C0, 0X2080, 0XE041,
  0XA001, 0X60C0, 0X6180, 0XA141, 0X6300, 0XA3C1, 0XA281, 0X6240,
  0X6600, 0XA6C1, 0XA781, 0X6740, 0XA501, 0X65C0, 0X6480, 0XA441,
  0X6C00, 0XACC1, 0XAD81, 0X6D40, 0XAF01, 0X6FC0, 0X6E80, 0XAE41,
  0XAA01, 0X6AC0, 0X6B80, 0XAB41, 0X6900, 0XA9C1, 0XA881, 0X6840,
  0X7800, 0XB8C1, 0XB981, 0X7940, 0XBB01, 0X7BC0, 0X7A80, 0XBA41,
  0XBE01, 0X7EC0, 0X7F80, 0XBF41, 0X7D00, 0XBDC1, 0XBC81, 0X7C40,
  0XB401, 0X74C0, 0X7580, 0XB541, 0X7700, 0XB7C1, 0XB681, 0X7640,
  0X7200, 0XB2C1, 0XB381, 0X7340, 0XB101, 0X71C0, 0X7080, 0XB041,
  0X5000, 0X90C1, 0X9181, 0X5140, 0X9301, 0X53C0, 0X5280, 0X9241,
  0X9601, 0X56C0, 0X5780, 0X9741, 0X5500, 0X95C1, 0X9481, 0X5440,
  0X9C01, 0X5CC0, 0X5D80, 0X9D41, 0X5F00, 0X9FC1, 0X9E81, 0X5E40,
  0X5A00, 0X9AC1, 0X9B81, 0X5B40, 0X9901, 0X59C0, 0X5880, 0X9841,
  0X8801, 0X48C0, 0X4980, 0X8941, 0X4B00, 0X8BC1, 0X8A81, 0X4A40,
  0X4E00, 0X8EC1, 0X8F81, 0X4F40, 0X8D01, 0X4DC0, 0X4C80, 0X8C41,
  0X4400, 0X84C1, 0X8581, 0X4540, 0X8701, 0X47C0, 0X4680, 0X8641,
  0X8201, 0X42C0, 0X4380, 0X8341, 0X4100, 0X81C1, 0X8081, 0X4040];

 

class ElevatorDataEncoder {

  ///
  /// 서비스 요청 데이터 인코딩
  ///
  encodeServiceRequest(cmd) {
    
    // 버퍼 만들기
    const buffer = Buffer.alloc(13);
    
    // STX 1 byte 쓰기
    buffer.writeUInt8(0xF0, 0);

    // Type 1 byte 쓰기 : Robot의 'R'
    buffer.writeUInt8(0x52, 1);

    // Length 4 byte 쓰기 : Data 길이 (나중에 설정)
    buffer.writeUInt32BE(4, 2);

    // 명령 1 byte 쓰기 
    // 시작: 0x53, 종료: 0x45
    buffer.writeUInt8(cmd, 6);

    // Number 값 1 : 1 byte 쓰기 (로봇 대수)
    buffer.writeUInt8(1, 7);
    
    // Reserved 2 bytes
    buffer.writeUInt8(0, 8);
    buffer.writeUInt8(0, 9);

    // Checksum 2 bytes : STX, ETX와 Checksum을 제외한 Data의 CRC16
    const dataBuffer = buffer.slice(1, buffer.length - 3);
    console.log(`dataBuffer : ${dataBuffer.toString('hex').toUpperCase()}`);

    const crcValue = this.getCRC(dataBuffer);
    //const crcValue = crc16('MODBUS', dataBuffer);
     
    console.log(`crc16 : ${crcValue.toString(16)}`)

    buffer.writeUInt16BE(crcValue, 10);

    // ETX 1 byte : 패킷의 끝 (0xF4)
    buffer.writeUInt8(0xF4, 12);

  
    return buffer;
  }
    
  ///
  /// 서비스 값 디코딩
  ///
  decodeServiceValue(buffer) {
    
    // 명령 : 1 byte
    // 시작: 0x53, 종료: 0x45
    const cmd = buffer.readUInt8(0);
    let command = '';
    if (cmd == 0x53) {
      command = 'serviceStart';
    } else if (cmd == 0x45) {
      command = 'serviceEnd';
    }

    // Number 값 : 1 byte (엘리베이터 대수)
    const elevatorCount = buffer.readUInt8(1);
 
    // Reserved 2 bytes
    const reserved1 = buffer.readUInt8(2);
    const reserved2 = buffer.readUInt8(3);
    
    const output = {
        command: command,
        elevatorCount: elevatorCount,
        reserved1: reserved1,
        reserved2: reserved2,
    }

    return output;
  }
    
  ///
  /// 서비스 응답 데이터 인코딩
  ///
  encodeServiceResponse(cmd) {
    
    // 버퍼 만들기
    const buffer = Buffer.alloc(13);
    
    // STX 1 byte 쓰기
    buffer.writeUInt8(0xF0, 0);

    // Type 1 byte 쓰기 : Elevator의 'E'
    buffer.writeUInt8(0x45, 1);

    // Length 4 byte 쓰기 : Data 길이 (나중에 설정)
    buffer.writeUInt32BE(4, 2);

    // 명령 1 byte 쓰기 
    // 시작: 0x53, 종료: 0x45
    buffer.writeUInt8(cmd, 6);

    // Number 값 1 : 1 byte 쓰기 (엘리베이터 대수)
    buffer.writeUInt8(1, 7);
    
    // Reserved 2 bytes
    buffer.writeUInt8(0, 8);
    buffer.writeUInt8(0, 9);

    // Checksum 2 bytes : STX, ETX와 Checksum을 제외한 Data의 CRC16
    const dataBuffer = buffer.slice(1, buffer.length - 3);
    console.log(`dataBuffer : ${dataBuffer.toString('hex').toUpperCase()}`);

    //const crcValue = this.computeCRC(dataBuffer);
    const crcValue = crc16('MODBUS', dataBuffer);
    console.log(`crc16 : ${crcValue.toString(16)}`)

    buffer.writeUInt16BE(crcValue, 10);

    // ETX 1 byte : 패킷의 끝 (0xF4)
    buffer.writeUInt8(0xF4, 12);

  
    return buffer;
  }

  ///
  /// 로봇정보 데이터 인코딩
  ///
  encodeRobotInfoRequest(robotId, elevatorId, floorId, controlRequest, robotStatus1, robotStatus2) {
    
    // 버퍼 만들기
    const buffer = Buffer.alloc(17);
    
    // STX 1 byte 쓰기
    buffer.writeUInt8(0xF0, 0);

    // Type 1 byte 쓰기 : Robot의 'r'
    buffer.writeUInt8(0x72, 1);

    // Length 4 byte 쓰기 : Robot Data 길이 (나중에 설정)
    buffer.writeUInt32BE(0, 2);

    // 로봇 ID 1 byte 쓰기 : 로봇의 식별번호 1~255
    buffer.writeUInt8(robotId, 6);

    // 로봇의 상태 값 1 : 1 byte 쓰기

    // Byte0 Bit0 충전중
    // Byte0 Bit1 탑승변경 (탑승 불가상태 또는 다른 호기 탑승)
    // Byte0 Bit2 하차완료
    // Byte0 Bit3 하차중
    // Byte0 Bit4 탑승완료
    // Byte0 Bit5 탑승중
    // Byte0 Bit6 탑승대기
    // Byte0 Bit7 층내이동

    if (robotStatus1) {
      buffer.writeUInt8(robotStatus1, 7);
    } else {
        
      //const robotStatus1 = 1;  //  00000001  충전중
      //const robotStatus1 = 1 << 1;  //  00000010  탑승변경
      //const robotStatus1 = 1 << 2;  //  00000100  하차완료
      //const robotStatus1 = 1 << 6;  //  01000000  탑승대기

      buffer.writeUInt8(0x00, 7);
    }

    // 로봇의 상태 값 2 : 1 byte 쓰기

    // Byte1 Bit3-Bit0 Reserved
    // Byte1 Bit4 통신상태 (1이면 접속된 상태)
    // Byte1 Bit5 하차실패
    // Byte1 Bit6 탑승실패
    // Byte1 Bit7 고장

    //const robotStatus1 = 1 << 4;  //  00010000  통신상태

    if (robotStatus2) {
      buffer.writeUInt8(robotStatus2, 8);
    } else {
      buffer.writeUInt8(0x00, 8);
    }

    // Target ID 1 byte 쓰기 : 로봇이 호출을 해야 하는 Elevator ID, 기본값 0x00
    // 1호기는 0x01, 2호기는 0x02
    buffer.writeUInt8(elevatorId, 9);

    // Target Idx 1 byte 쓰기 : 로봇이 탑승 또는 하차를 해야 하는 층, 기본값 0x00
    // 최하층 0x01 (지하층부터 어떻게 되는지 테스트 필요)
    buffer.writeUInt8(floorId, 10);

    // Request 제어 요청 : 1 byte 쓰기

    // 제어요청 없으면 기본값 0x00
    // Byte0 Bit1-Bit0 Reserved
    // Byte0 Bit2 도어방향 (0:정면도어, 1:후면도어)
    // Byte0 Bit3 PDC(Push Door Close) 도어 닫힘 버튼
    // Byte0 Bit4 PDO(Push Door Open) 도어 열림 버튼
    // Byte0 Bit5 카 콜 버튼 등록
    // Byte0 Bit6 홀 콜 하향 버튼 등록
    // Byte0 Bit7 홀 콜 상향 버튼 등록

    //const controlRequest = 1 << 4;  //  00010000  카 콜 버튼 등록

    buffer.writeUInt8(controlRequest, 11);

    // Reserved 2 bytes
    buffer.writeUInt8(0, 12);
    buffer.writeUInt8(0, 13);

    // Length 4 byte 쓰기 : Robot Data 길이
    const bufferLength = buffer.byteLength - 9;
    buffer.writeUInt32BE(bufferLength, 2);
  
    // Checksum 2 bytes : STX, ETX와 Checksum을 제외한 Data의 CRC16
    const dataBuffer = buffer.slice(1, buffer.length - 3);
    console.log(`dataBuffer : ${dataBuffer.toString('hex').toUpperCase()}`);

    const crcValue = this.getCRC(dataBuffer);
    //const crcValue = crc16('MODBUS', dataBuffer);
    console.log(`crc16 : ${crcValue.toString(16)}`)

    buffer.writeUInt16BE(crcValue, 14);

    
    // TEST
    // buffer.writeUInt8(0x37, 14);
    // buffer.writeUInt8(0x63, 15);



    // ETX 1 byte : 패킷의 끝 (0xF4)
    buffer.writeUInt8(0xF4, 16);

    return buffer;
  }
    
  ///
  /// 로봇정보 값 디코딩
  ///
  decodeRobotInfoValue(buffer) {
    
    // 로봇 ID : 1 byte
    // 로봇의 식별번호 1~255
    const robotId = buffer.readUInt8(0);

    // 로봇의 상태 값 1 : 1 byte
    
    // Byte0 Bit0 충전중
    // Byte0 Bit1 탑승변경 (탑승 불가상태 또는 다른 호기 탑승)
    // Byte0 Bit2 하차완료
    // Byte0 Bit3 하차중
    // Byte0 Bit4 탑승완료
    // Byte0 Bit5 탑승중
    // Byte0 Bit6 탑승대기
    // Byte0 Bit7 층내이동

    const robotStatus1 = buffer.readUInt8(1);
    
    // 로봇의 상태 값 2 : 1 byte

    // Byte1 Bit3-Bit0 Reserved
    // Byte1 Bit4 통신상태 (1이면 접속된 상태)
    // Byte1 Bit5 하차실패
    // Byte1 Bit6 탑승실패
    // Byte1 Bit7 고장

    const robotStatus2 = buffer.readUInt8(2);
    
    // Target ID 1 byte : 로봇이 호출을 해야 하는 Elevator ID, 기본값 0x00
    // 1호기는 0x01, 2호기는 0x02
    const elevatorId = buffer.readUInt8(3);

    // Target Idx 1 byte : 로봇이 탑승 또는 하차를 해야 하는 층, 기본값 0x00
    // 최하층 0x01 (지하층부터 어떻게 되는지 테스트 필요)
    const floorId = buffer.readUInt8(4);


    // Request 제어 요청 : 1 byte

    // 제어요청 없으면 기본값 0x00
    // Byte0 Bit1-Bit0 Reserved
    // Byte0 Bit2 도어방향 (0:정면도어, 1:후면도어)
    // Byte0 Bit3 PDC(Push Door Close) 도어 닫힘 버튼
    // Byte0 Bit4 PDO(Push Door Open) 도어 열림 버튼
    // Byte0 Bit5 카 콜 버튼 등록
    // Byte0 Bit6 홀 콜 하향 버튼 등록
    // Byte0 Bit7 홀 콜 상향 버튼 등록

    const controlRequest = buffer.readUInt8(5);
 
    // Reserved 2 bytes
    const reserved1 = buffer.readUInt8(6);
    const reserved2 = buffer.readUInt8(7);
    
    const output = {
        robotId: robotId,
        robotStatus1: robotStatus1,
        robotStatus2: robotStatus2,
        elevatorId: elevatorId,
        floorId: floorId,
        controlRequest: controlRequest,
        reserved1: reserved1,
        reserved2: reserved2
    }

    return output;
  }
    
  ///
  /// 로봇정보 응답 데이터 인코딩
  ///
  encodeRobotInfoResponse(robotId, elevatorId, floorId, controlRequest, robotStatus1) {
    
    // 버퍼 만들기
    const buffer = Buffer.alloc(17);
    
    // STX 1 byte 쓰기
    buffer.writeUInt8(0xF0, 0);

    // Type 1 byte 쓰기 : ACK의 'A'
    buffer.writeUInt8(0x61, 1);

    // Length 4 byte 쓰기 : Data 길이 (나중에 설정)
    buffer.writeUInt32BE(8, 2);

    // 로봇ID 1 byte 쓰기 
    buffer.writeUInt8(robotId, 6);

    // 로봇상태값 2 byte 쓰기 
    if (robotStatus1) {
      buffer.writeUInt8(robotStatus1, 7);
    } else {
      buffer.writeUInt8(0, 7);
    }

    buffer.writeUInt8(0, 8);
    
    // 엘리베이터 ID 1 byte 쓰기 
    buffer.writeUInt8(elevatorId, 9);
  
    // 층 ID 1 byte 쓰기 
    buffer.writeUInt8(floorId, 10);

    // 제어요청 1 byte 쓰기 
    buffer.writeUInt8(controlRequest, 11);

    // Reserved 2 bytes
    buffer.writeUInt8(0, 12);
    buffer.writeUInt8(0, 13);


    // Length 4 byte 쓰기 : Robot Data 길이
    const bufferLength = buffer.byteLength - 9;
    buffer.writeUInt32BE(bufferLength, 2);
  

    // Checksum 2 bytes : STX, ETX와 Checksum을 제외한 Data의 CRC16
    const dataBuffer = buffer.slice(1, buffer.length - 3);
    const crcValue = this.getCRC(dataBuffer);
    console.log(`crc16 : ${crcValue.toString(16)}`)

    buffer.writeUInt16BE(crcValue, 14);

    // ETX 1 byte : 패킷의 끝 (0xF4)
    buffer.writeUInt8(0xF4, 16);

  
    return buffer;
  }

  ///
  /// 엘리베이터정보 데이터 인코딩
  ///
  /// 'available' 엘리베이터 이용 가능
  /// 'frontopen' 정면도어 열림
  /// 'backopen' 후면도어 열림
  /// 'up' 주행방향 상향
  /// 'down' 주행방향 하향
  /// 'stop' 주행방향 없음
  /// 'frontclose' 전면도어 닫힘
  /// 'backclose' 후면도어 닫힘
  ///
  encodeElevatorInfoResponse(elevatorId, floorId, elevatorStatus) {
    
    // 버퍼 만들기
    const buffer = Buffer.alloc(143);
    
    // STX 1 byte 쓰기
    buffer.writeUInt8(0xF0, 0);

    // Type 1 byte 쓰기 : Elevator의 'e'
    buffer.writeUInt8(0x65, 1);

    // Length 4 byte 쓰기 : Robot Data 길이 (나중에 설정)
    buffer.writeUInt32BE(0, 2);

    // 엘리베이터 ID 1 byte 쓰기 : 엘리베이터의 식별번호 1~255
    buffer.writeUInt8(elevatorId, 6);

    // 엘리베이터 현재 층 1 byte 쓰기 : 최하층 0x01
    buffer.writeUInt8(floorId, 7);

    // 엘리베이터 운행상태 4 byte 쓰기
    if (elevatorStatus == 'available') {    // 엘리베이터 이용 가능
      buffer.writeUInt8(0x00, 8);
      buffer.writeUInt8(0x00, 9);
      buffer.writeUInt8(1 << 2, 10); 
      buffer.writeUInt8(0x00, 11);
    } else if (elevatorStatus == 'frontopen') {   // 정면도어 열림
      buffer.writeUInt8(0x00, 8);
      buffer.writeUInt8(0x00, 9);
      buffer.writeUInt8(1 << 1, 10); 
      buffer.writeUInt8(0x00, 11);
    } else if (elevatorStatus == 'backopen') {   // 후면도어 열림
      buffer.writeUInt8(0x00, 8);
      buffer.writeUInt8(0x00, 9);
      buffer.writeUInt8(1, 10); 
      buffer.writeUInt8(0x00, 11);
    } else if (elevatorStatus == 'up') {   // 주행방향 상향
      buffer.writeUInt8(0x00, 8);
      buffer.writeUInt8(0x00, 9);
      buffer.writeUInt8(0x00, 10); 
      buffer.writeUInt8(1 << 4, 11); 
    } else if (elevatorStatus == 'down') {   // 주행방향 하향
      buffer.writeUInt8(0x00, 8);
      buffer.writeUInt8(0x00, 9);
      buffer.writeUInt8(0x00, 10); 
      buffer.writeUInt8(1 << 3, 11); 
    } else if (elevatorStatus == 'stop') {   // 주행방향 없음
      buffer.writeUInt8(0x00, 8);
      buffer.writeUInt8(0x00, 9);
      buffer.writeUInt8(0x00, 10); 
      buffer.writeUInt8(1 << 2, 11); 
    } else if (elevatorStatus == 'frontclose') {   // 전면도어 닫힘
      buffer.writeUInt8(0x00, 8);
      buffer.writeUInt8(0x00, 9);
      buffer.writeUInt8(0x00, 10); 
      buffer.writeUInt8(1 << 1, 11); 
    } else if (elevatorStatus == 'backclose') {   // 후면도어 닫힘
      buffer.writeUInt8(0x00, 8);
      buffer.writeUInt8(0x00, 9);
      buffer.writeUInt8(0x00, 10); 
      buffer.writeUInt8(1, 11); 
    }

    // 홀 콜 상향버튼 등록 상태 32 byte
    buffer.writeUInt32BE(0, 12);
    buffer.writeUInt32BE(0, 16);
    buffer.writeUInt32BE(0, 20);
    buffer.writeUInt32BE(0, 24);
    buffer.writeUInt32BE(0, 28);
    buffer.writeUInt32BE(0, 32);
    buffer.writeUInt32BE(0, 36);
    buffer.writeUInt32BE(0, 40);

    // 홀 콜 하향버튼 등록 상태 32 byte
    buffer.writeUInt32BE(0, 44);
    buffer.writeUInt32BE(0, 48);
    buffer.writeUInt32BE(0, 52);
    buffer.writeUInt32BE(0, 56);
    buffer.writeUInt32BE(0, 60);
    buffer.writeUInt32BE(0, 64);
    buffer.writeUInt32BE(0, 68);
    buffer.writeUInt32BE(0, 72);

    // 카 콜 등록 상태 32 byte
    buffer.writeUInt32BE(0, 76);
    buffer.writeUInt32BE(0, 80);
    buffer.writeUInt32BE(0, 84);
    buffer.writeUInt32BE(0, 88);
    buffer.writeUInt32BE(0, 92);
    buffer.writeUInt32BE(0, 96);
    buffer.writeUInt32BE(0, 100);
    buffer.writeUInt32BE(0, 104);

    // 잠김 층 상태 32 byte
    buffer.writeUInt32BE(0, 108);
    buffer.writeUInt32BE(0, 112);
    buffer.writeUInt32BE(0, 116);
    buffer.writeUInt32BE(0, 120);
    buffer.writeUInt32BE(0, 124);
    buffer.writeUInt32BE(0, 128);
    buffer.writeUInt32BE(0, 132);
    buffer.writeUInt32BE(0, 136);
 
  
    // Length 4 byte 쓰기 : Robot Data 길이
    const bufferLength = buffer.byteLength - 9;
    buffer.writeUInt32BE(bufferLength, 2);
  

    // Checksum 2 bytes : STX, ETX와 Checksum을 제외한 Data의 CRC16
    const dataBuffer = buffer.slice(1, buffer.length - 3);
    const crcValue = this.getCRC(dataBuffer);
    console.log(`crc16 : ${crcValue}`)

    buffer.writeUInt16BE(crcValue, 14);

    // ETX 1 byte : 패킷의 끝 (0xF4)
    buffer.writeUInt8(0xF4, 16);

  
    return buffer;
  }
    
  
  ///
  /// 엘리베이터정보 값 디코딩
  ///
  decodeElevatorInfoValue(buffer) {
    console.log(`Elevator value length : ${buffer.length}`);
    
    let elevatorCount = buffer.length / 134;
    let outputArray = [];

    for (let i = 0; i < elevatorCount; i++) {

      // 엘리베이터 ID : 1 byte
      // 엘리베이터의 식별번호 1~255
      const elevatorId = buffer.readUInt8(134*i + 0);

      // 엘리베이터 현재 층 : 1 byte
      // 최하층 0x01
      const floorId = buffer.readUInt8(134*i + 1);
  
      // 엘리베이터 운행상태 : 4 byte
      let elevatorStatus1 = '';
      let elevatorStatus2 = '';
      let elevatorStatus3 = '';
      let elevatorStatus4 = '';

      let status1 = buffer.readUInt8(134*i + 2);
      let status2 = buffer.readUInt8(134*i + 3);
      let status3 = buffer.readUInt8(134*i + 4);
      let status4 = buffer.readUInt8(134*i + 5);

      let status1Str = toBinaryString(status1);
      let status2Str = toBinaryString(status2);
      let status3Str = toBinaryString(status3);
      let status4Str = toBinaryString(status4);

      console.log(`status1 -> ${status1Str}`);
      console.log(`status2 -> ${status2Str}`);
      console.log(`status3 -> ${status3Str}`);
      console.log(`status4 -> ${status4Str}`);
  
  
      if (status1Str.charAt(0) == 1) {   // 고장 (Fault Detection)
        if (elevatorStatus1.length > 0) {
          elevatorStatus1 += ',';
        }
        elevatorStatus1 = 'FD';
      } 
      if (status1Str.charAt(1) == 1) {   // 야간 저속 (Night Silence)
        if (elevatorStatus1.length > 0) {
          elevatorStatus1 += ',';
        }
        elevatorStatus1 = 'NS';
      }
      if (status1Str.charAt(2) == 1) {   // 과중 (Overload)
        if (elevatorStatus1.length > 0) {
          elevatorStatus1 += ',';
        }
        elevatorStatus1 = 'OVR';
      }
      if (status1Str.charAt(3) == 1) {   // 과중 (Hall call bypass 80% 하중)
        if (elevatorStatus1.length > 0) {
          elevatorStatus1 += ',';
        }
        elevatorStatus1 = 'HCB';
      }
      if (status1Str.charAt(4) == 1) {   // 파킹 (Parking)
        if (elevatorStatus1.length > 0) {
          elevatorStatus1 += ',';
        }
        elevatorStatus1 = 'Parking';
      }
      if (status1Str.charAt(5) == 1) {    // 전용 (Independent)
        if (elevatorStatus1.length > 0) {
          elevatorStatus1 += ',';
        }
        elevatorStatus1 = 'IND';
      }
      if (status1Str.charAt(6) == 1) {   // 점검중 (Inspection)
        if (elevatorStatus1.length > 0) {
          elevatorStatus1 += ',';
        }
        elevatorStatus1 = 'INS';
      }
      if (status1Str.charAt(7) == 1) {    // 자동 (Automatic)
        if (elevatorStatus1.length > 0) {
          elevatorStatus1 += ',';
        }
        elevatorStatus1 = 'AUT';      
      }

      
      if (status2Str.charAt(0) == 1) {   // 빌딩스웨이 1단계
        if (elevatorStatus2.length > 0) {
          elevatorStatus2 += ',';
        }
        elevatorStatus2 = 'SW1';
      } 
      if (status2Str.charAt(1) == 1) {   // 빌딩스웨이 2단계
        if (elevatorStatus2.length > 0) {
          elevatorStatus2 += ',';
        }
        elevatorStatus2 = 'SW2';
      }
      if (status2Str.charAt(2) == 1) {   // 빌딩스웨이 3단계
        if (elevatorStatus2.length > 0) {
          elevatorStatus2 += ',';
        }
        elevatorStatus2 = 'SW3';
      }
      if (status2Str.charAt(3) == 1) {   // Car to Car Rescue
        if (elevatorStatus2.length > 0) {
          elevatorStatus2 += ',';
        }
        elevatorStatus2 = 'RSQ';
      }
      if (status2Str.charAt(4) == 1) {   // Automatic Rescue with backup battery
        if (elevatorStatus2.length > 0) {
          elevatorStatus2 += ',';
        }
        elevatorStatus2 = 'ARD';
      }
      if (status2Str.charAt(5) == 1) {   // 
        if (elevatorStatus2.length > 0) {
          elevatorStatus2 += ',';
        }
        elevatorStatus2 = 'VIP';
      }
      if (status2Str.charAt(6) == 1) {   //  
        if (elevatorStatus2.length > 0) {
          elevatorStatus2 += ',';
        }
        elevatorStatus2 = 'CANNING';
      }
      if (status2Str.charAt(7) == 1) {    // EC (Seismic)
        if (elevatorStatus2.length > 0) {
          elevatorStatus2 += ',';
        }
        elevatorStatus2 = 'EC';      
      }

      if (status3Str.charAt(0) == 1) {   // Machine room's over-temperature - Finished
        if (elevatorStatus3.length > 0) {
          elevatorStatus3 += ',';
        }
        elevatorStatus3 += 'TCF';
      } 
      if (status3Str.charAt(1) == 1) {   // In - Machine room's over-temperature
        if (elevatorStatus3.length > 0) {
          elevatorStatus3 += ',';
        }
        elevatorStatus3 += 'TC';
      } 
      if (status3Str.charAt(2) == 1) {   // This car is in emergency power control operation
        if (elevatorStatus3.length > 0) {
          elevatorStatus3 += ',';
        }
        elevatorStatus3 += 'PC';
      } 
      if (status3Str.charAt(3) == 1) {   // Pit 침수
        if (elevatorStatus3.length > 0) {
          elevatorStatus3 += ',';
        }
        elevatorStatus3 += 'PITW';
      } 
      if (status3Str.charAt(4) == 1) {   // 방범 동작 중
        if (elevatorStatus3.length > 0) {
          elevatorStatus3 += ',';
        }
        elevatorStatus3 += 'CAPT';
      } 
      if (status3Str.charAt(5) == 1) {    // 자가발
        if (elevatorStatus3.length > 0) {
          elevatorStatus3 += ',';
        }
        elevatorStatus3 += 'EPNP';
      } 
      if (status3Str.charAt(6) == 1) {   // 전면 도어가 완전히 열린 상태
        if (elevatorStatus3.length > 0) {
          elevatorStatus3 += ',';
        }
        elevatorStatus3 += 'DOL-Front';
      } 
      if (status3Str.charAt(7) == 1) {    // 후면 도어가 완전히 열린 상태
        if (elevatorStatus3.length > 0) {
          elevatorStatus3 += ',';
        }
        elevatorStatus3 += 'DOL-Rear';      
      }

      if (status4Str.charAt(0) == 1) {   // Lobby recall - third
        if (elevatorStatus4.length > 0) {
          elevatorStatus4 += ',';
        }
        elevatorStatus4 = 'HML3';
      }
      if (status4Str.charAt(1) == 1) {   // Lobby recall - second
        if (elevatorStatus4.length > 0) {
          elevatorStatus4 += ',';
        }
        elevatorStatus4 = 'HML2';
      } 
      if (status4Str.charAt(2) == 1) {    //
        if (elevatorStatus4.length > 0) {
          elevatorStatus4 += ',';
        }
        elevatorStatus4 = 'Parking2';
      } 
      if (status4Str.charAt(3) == 1) {   // 엘리베이터 주행방향이 상향
        if (elevatorStatus4.length > 0) {
          elevatorStatus4 += ',';
        }
        elevatorStatus4 = 'Up';
      } 
      if (status4Str.charAt(4) == 1) {   // 엘리베이터 주행방향이 하향
        if (elevatorStatus4.length > 0) {
          elevatorStatus4 += ',';
        }
        elevatorStatus4 = 'Down';
      } 
      if (status4Str.charAt(5) == 1) {    // 엘리베이터 주행방향이 없는 상태
        if (elevatorStatus4.length > 0) {
          elevatorStatus4 += ',';
        }
        elevatorStatus4 = 'Stop';
      } 
      if (status4Str.charAt(6) == 1) {   // 전면 도어가 완전히 닫힌 상태
        if (elevatorStatus4.length > 0) {
          elevatorStatus4 += ',';
        }
        elevatorStatus4 = 'CDCF';
      } 
      if (status4Str.charAt(7) == 1) {    // 후면 도어가 완전히 닫힌 상태
        if (elevatorStatus4.length > 0) {
          elevatorStatus4 += ',';
        }
        elevatorStatus4 = 'CDCR';      
      }
    

      // 홀 콜 상향버튼 등록 상태 32 byte
      const upMatrix1 = buffer.readUInt32BE(134*i + 6);
      const upMatrix2 = buffer.readUInt32BE(134*i + 10);
      const upMatrix3 = buffer.readUInt32BE(134*i + 14);
      const upMatrix4 = buffer.readUInt32BE(134*i + 18);
      const upMatrix5 = buffer.readUInt32BE(134*i + 22);
      const upMatrix6 = buffer.readUInt32BE(134*i + 26);
      const upMatrix7 = buffer.readUInt32BE(134*i + 30);
      const upMatrix8 = buffer.readUInt32BE(134*i + 34);

      // 홀 콜 하향버튼 등록 상태 32 byte
      const downMatrix1 = buffer.readUInt32BE(134*i + 38);
      const downMatrix2 = buffer.readUInt32BE(134*i + 42);
      const downMatrix3 = buffer.readUInt32BE(134*i + 46);
      const downMatrix4 = buffer.readUInt32BE(134*i + 50);
      const downMatrix5 = buffer.readUInt32BE(134*i + 54);
      const downMatrix6 = buffer.readUInt32BE(134*i + 58);
      const downMatrix7 = buffer.readUInt32BE(134*i + 62);
      const downMatrix8 = buffer.readUInt32BE(134*i + 66);

      // 카 콜 등록 상태 32 byte
      const carCallMatrix1 = buffer.readUInt32BE(134*i + 70);
      const carCallMatrix2 = buffer.readUInt32BE(134*i + 74);
      const carCallMatrix3 = buffer.readUInt32BE(134*i + 78);
      const carCallMatrix4 = buffer.readUInt32BE(134*i + 82);
      const carCallMatrix5 = buffer.readUInt32BE(134*i + 86);
      const carCallMatrix6 = buffer.readUInt32BE(134*i + 90);
      const carCallMatrix7 = buffer.readUInt32BE(134*i + 94);
      const carCallMatrix8 = buffer.readUInt32BE(134*i + 98);

      // 잠김 층 상태 32 byte
      const lockMatrix1 = buffer.readUInt32BE(134*i + 102);
      const lockMatrix2 = buffer.readUInt32BE(134*i + 106);
      const lockMatrix3 = buffer.readUInt32BE(134*i + 110);
      const lockMatrix4 = buffer.readUInt32BE(134*i + 114);
      const lockMatrix5 = buffer.readUInt32BE(134*i + 118);
      const lockMatrix6 = buffer.readUInt32BE(134*i + 122);
      const lockMatrix7 = buffer.readUInt32BE(134*i + 126);
      const lockMatrix8 = buffer.readUInt32BE(134*i + 130);
  
      const output = {
        elevatorId: elevatorId,
        floorId: floorId,
        elevatorStatus1: elevatorStatus1,
        elevatorStatus2: elevatorStatus2,
        elevatorStatus3: elevatorStatus3,
        elevatorStatus4: elevatorStatus4,
        upMatrix1: upMatrix1,
        upMatrix2: upMatrix2,
        upMatrix3: upMatrix3,
        upMatrix4: upMatrix4,
        upMatrix5: upMatrix5,
        upMatrix6: upMatrix6,
        upMatrix7: upMatrix7,
        upMatrix8: upMatrix8,
        downMatrix1: downMatrix1,
        downMatrix2: downMatrix2,
        downMatrix3: downMatrix3,
        downMatrix4: downMatrix4,
        downMatrix5: downMatrix5,
        downMatrix6: downMatrix6,
        downMatrix7: downMatrix7,
        downMatrix8: downMatrix8,
        carCallMatrix1: carCallMatrix1,
        carCallMatrix2: carCallMatrix2,
        carCallMatrix3: carCallMatrix3,
        carCallMatrix4: carCallMatrix4,
        carCallMatrix5: carCallMatrix5,
        carCallMatrix6: carCallMatrix6,
        carCallMatrix7: carCallMatrix7,
        carCallMatrix8: carCallMatrix8,
        lockMatrix1: lockMatrix1,
        lockMatrix2: lockMatrix2,
        lockMatrix3: lockMatrix3,
        lockMatrix4: lockMatrix4,
        lockMatrix5: lockMatrix5,
        lockMatrix6: lockMatrix6,
        lockMatrix7: lockMatrix7,
        lockMatrix8: lockMatrix8,
      }

      outputArray.push(output);
    }
    
    return outputArray;
  }
    

  ///
  /// CRC16 계산
  ///
  computeCRC(buffer) {
    let crc = 0xFFFF;
    let odd;

    for (let i = 0; i < buffer.length; i++) {
        crc = crc ^ buffer[i];

        for (let j = 0; j < 8; j++) {
            odd = crc & 0x0001;
            crc = crc >> 1;
            if (odd) {
                crc = crc ^ 0xA001;
            }
        }
    }

    return crc;
  };

  ///
  /// CRC16 계산
  ///

  getCRC(buffer) {

    const wCRCTable = [
        0X0000, 0XC0C1, 0XC181, 0X0140, 0XC301, 0X03C0, 0X0280, 0XC241,
        0XC601, 0X06C0, 0X0780, 0XC741, 0X0500, 0XC5C1, 0XC481, 0X0440,
        0XCC01, 0X0CC0, 0X0D80, 0XCD41, 0X0F00, 0XCFC1, 0XCE81, 0X0E40,
        0X0A00, 0XCAC1, 0XCB81, 0X0B40, 0XC901, 0X09C0, 0X0880, 0XC841,
        0XD801, 0X18C0, 0X1980, 0XD941, 0X1B00, 0XDBC1, 0XDA81, 0X1A40,
        0X1E00, 0XDEC1, 0XDF81, 0X1F40, 0XDD01, 0X1DC0, 0X1C80, 0XDC41,
        0X1400, 0XD4C1, 0XD581, 0X1540, 0XD701, 0X17C0, 0X1680, 0XD641,
        0XD201, 0X12C0, 0X1380, 0XD341, 0X1100, 0XD1C1, 0XD081, 0X1040,
        0XF001, 0X30C0, 0X3180, 0XF141, 0X3300, 0XF3C1, 0XF281, 0X3240,
        0X3600, 0XF6C1, 0XF781, 0X3740, 0XF501, 0X35C0, 0X3480, 0XF441,
        0X3C00, 0XFCC1, 0XFD81, 0X3D40, 0XFF01, 0X3FC0, 0X3E80, 0XFE41,
        0XFA01, 0X3AC0, 0X3B80, 0XFB41, 0X3900, 0XF9C1, 0XF881, 0X3840,
        0X2800, 0XE8C1, 0XE981, 0X2940, 0XEB01, 0X2BC0, 0X2A80, 0XEA41,
        0XEE01, 0X2EC0, 0X2F80, 0XEF41, 0X2D00, 0XEDC1, 0XEC81, 0X2C40,
        0XE401, 0X24C0, 0X2580, 0XE541, 0X2700, 0XE7C1, 0XE681, 0X2640,
        0X2200, 0XE2C1, 0XE381, 0X2340, 0XE101, 0X21C0, 0X2080, 0XE041,
        0XA001, 0X60C0, 0X6180, 0XA141, 0X6300, 0XA3C1, 0XA281, 0X6240,
        0X6600, 0XA6C1, 0XA781, 0X6740, 0XA501, 0X65C0, 0X6480, 0XA441,
        0X6C00, 0XACC1, 0XAD81, 0X6D40, 0XAF01, 0X6FC0, 0X6E80, 0XAE41,
        0XAA01, 0X6AC0, 0X6B80, 0XAB41, 0X6900, 0XA9C1, 0XA881, 0X6840,
        0X7800, 0XB8C1, 0XB981, 0X7940, 0XBB01, 0X7BC0, 0X7A80, 0XBA41,
        0XBE01, 0X7EC0, 0X7F80, 0XBF41, 0X7D00, 0XBDC1, 0XBC81, 0X7C40,
        0XB401, 0X74C0, 0X7580, 0XB541, 0X7700, 0XB7C1, 0XB681, 0X7640,
        0X7200, 0XB2C1, 0XB381, 0X7340, 0XB101, 0X71C0, 0X7080, 0XB041,
        0X5000, 0X90C1, 0X9181, 0X5140, 0X9301, 0X53C0, 0X5280, 0X9241,
        0X9601, 0X56C0, 0X5780, 0X9741, 0X5500, 0X95C1, 0X9481, 0X5440,
        0X9C01, 0X5CC0, 0X5D80, 0X9D41, 0X5F00, 0X9FC1, 0X9E81, 0X5E40,
        0X5A00, 0X9AC1, 0X9B81, 0X5B40, 0X9901, 0X59C0, 0X5880, 0X9841,
        0X8801, 0X48C0, 0X4980, 0X8941, 0X4B00, 0X8BC1, 0X8A81, 0X4A40,
        0X4E00, 0X8EC1, 0X8F81, 0X4F40, 0X8D01, 0X4DC0, 0X4C80, 0X8C41,
        0X4400, 0X84C1, 0X8581, 0X4540, 0X8701, 0X47C0, 0X4680, 0X8641,
        0X8201, 0X42C0, 0X4380, 0X8341, 0X4100, 0X81C1, 0X8081, 0X4040
    ];

    /*
    let nData = [...buffer];
    let wLength = nData.length;
    let wCRCWord = 0xFFFF;

    while (wLength--) {
        const nTemp = nData.shift() ^ wCRCWord;
        wCRCWord >>= 8;
        wCRCWord ^= wCRCTable[nTemp];
    }

    return wCRCWord;
    */

    let crc = 0xFFFF;
    for (const b of buffer) {
      crc = wCRCTable[(b ^ crc) & 0xFF] ^ (crc >> 8);
      //crc = wCRCTable[(crc ^ b) & 0xFF] ^ (crc >> 8);
      //crc = wCRCTable[(crc ^ b) & 0xFF] ^ (crc >> 8 & 0xFF);
      //crc = wCRCTable[(b ^ crc) & 0xFF] ^ (crc >> 8 & 0xFF);

    }

    //return crc & 0xffff;
    return crc;
  }


}

module.exports = ElevatorDataEncoder;

